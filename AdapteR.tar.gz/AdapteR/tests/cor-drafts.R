
require(gplots)
require(corrplot)
corrplot(cor(rEqnRtn))

corrplot(as.matrix(flCorr))

randomstocks <- sample(colnames(eqnRtn),
                       100)


flCorr <- cor(eqnRtn[,randomstocks])

corrplot(as.matrix(flCorr),
         method="color",
         outline = FALSE,
         order = "hclust",
         hclust.method = "ward",
         addrect = 10,
         tl.col="black",tl.cex = .5)


ord <- corrMatOrder(flCorr,
                    order = "hclust",
                    hclust.method = "ward")
flCorr <- flCorr[ord, ord]


library(seriation) ## for pimage and hmap
pimage(as.matrix(flCorr))

hmap(as.matrix(flCorr))


## heatmap with correlation-based distance, green-red color (greenred is 
## predefined) and optimal leaf ordering and no row label
dist_cor <- function(x) as.dist(1-cor(t(x)))
