#############################################################
## For in-database analytix the matrix is in the warehouse
## to begin with.
## 
## A remote matrix is easily created by specifying
##
m <- 
 eqnRtn <- FLMatrix(
         connection,
         database          = "FL_DEMO",
         matrix_table      = "finEquityReturns",
         matrix_id_value   = "",
         matrix_id_colname = "",
         row_id_colname    = "TxnDate",
         col_id_colname    = "TickerSymbol",
         cell_val_colname  = "EquityReturn")


dbGetQuery(connection,"select count( * ) from FL_Dev.tblSanofiData")



R <- dbGetQuery(connection,"HELP table FL_Dev.tblSanofiData")

dbGetQuery(connection,"SELECT columnname 
						  FROM dbc.columns
						  WHERE tablename='tblSanofiData' 
						  AND databasename='FL_Dev';
")


sD <- FLTable(connection,
              "FL_Dev",
              "tblSanofiData",
              "OBSID")


head(sD)

FLStartSession(connection,db_name = "FL_DEV")

dbGetQuery(connection,"select top 10 * from FL_DEV.tblSanofiData")



R <- dbSendQuery(
    connection,
    paste0("CALL FLWideToDeep('",
           remoteTable(sD),"', ",
           "'OBSID', ",
           "'FL_DEV.tblSanofiDataDeep', ",
           "'OBSID', 'VARID', 'NUM_VAL', ",
           " NULL,NULL,NULL,AnalysisID)"))





dbGetQuery(connection,"select count (*) from FL_DEV.tblSanofiDataDeep")

dbSendQuery(connection,"insert into FL_DEV.tblSanofiDataDeep SELECT a.OBSID, 0, 1 FROM FL_DEV.tblSanofiDataDeep a WHERE a.VARID=1")

dbSendQuery(connection,"insert into FL_DEV.tblSanofiDataDeep SELECT a.OBSID, VARID=-1, NUM_VAL=CASE FROM FL_DEV.tblSanofiDataDeep a,  WHERE a.VARID==1")


dbGetQuery(connection,"SELECT top 1 * FROM fzzlRegrDataPrepMap WHERE runstarttime=SELECT max(runstarttime) FROM fzzlRegrDataPrepInfo)")

## add dependant from column names in mapping table (varid=-1)
## add intercept (varid=0)


## do FLLogRegrSW for feature selection


names(sD)

rownames(sD)



sqlSendUpdate(connection,"drop table tblSanofiData;")

sqlSendUpdate(connection,"CREATE MULTISET TABLE tblSanofiData (   
 OBSID BIGINT ,
    LPA_Label   VARCHAR(250),
 dcSScN7P8_CTRL DOUBLE PRECISION ,
 dcSScN7P8_LPA DOUBLE PRECISION ,
 IPF_323_CTRL DOUBLE PRECISION ,
 IPF_323_LPA DOUBLE PRECISION ,
 IPF_330_CTRL DOUBLE PRECISION ,
 IPF_330_LPA DOUBLE PRECISION ,
 IPF_334_CTRL DOUBLE PRECISION ,
 IPF_334_LPA DOUBLE PRECISION ,
 IPF_358_1_CTRL DOUBLE PRECISION ,
 IPF_358_1_LPA DOUBLE PRECISION ,
 IPF_413_CTRL DOUBLE PRECISION ,
 IPF_413_LPA DOUBLE PRECISION ,
 IPF_Gi7_CTRL DOUBLE PRECISION ,
 IPF_Gi7_LPA DOUBLE PRECISION ,
 IPF_LL97_CTRL DOUBLE PRECISION ,
 IPF_LL97_LPA DOUBLE PRECISION ,
 IPFGi_2L2_CTRL DOUBLE PRECISION ,
 IPFGi_2L2_LPA DOUBLE PRECISION ,
 NHDF_1_P5_CTRL DOUBLE PRECISION ,
 NHDF_1_P5_LPA DOUBLE PRECISION ,
 NHDF_2_P5_CTRL DOUBLE PRECISION ,
 NHDF_2_P5_LPA DOUBLE PRECISION ,
 NHDF_3_P4_CTRL DOUBLE PRECISION ,
 NHDF_3_P4_LPA DOUBLE PRECISION ,
 NHDF_lot1_P6_12_08_2011_CTRL DOUBLE PRECISION ,
 NHDF_lot1_P6_CTRL             DOUBLE PRECISION ,
 NHDF_lot1_P6_LPA             DOUBLE PRECISION ,
 NHDF_lot1_P6_LPA_12_08_2011 DOUBLE PRECISION ,
 NHDF_lot2_P5_CTRL             DOUBLE PRECISION ,
 NHDF_lot2_P5_CTRL_15_12_2011 DOUBLE PRECISION ,
 NHDF_lot2_P5_LPA             DOUBLE PRECISION ,
 NHDF_lot2_P5_LPA_15_12_2011 DOUBLE PRECISION ,
 SSc10P5_24h_CTRL DOUBLE PRECISION ,
 SSc10P5_24h_LPA DOUBLE PRECISION ,
 SSc1P5_24h_CTRL DOUBLE PRECISION ,
 SSc1P5_24h_LPA     DOUBLE PRECISION ,
 SSc2P6_24h_CTRL DOUBLE PRECISION ,
 SSc2P6_24h_LPA     DOUBLE PRECISION ,
 SSc3P5_24h_CTRL DOUBLE PRECISION ,
 SSc3P5_24h_LPA     DOUBLE PRECISION ,
 SSc4P5_24h_CTRL DOUBLE PRECISION ,
 SSc4P5_24h_LPA     DOUBLE PRECISION ,
 SSc5P6_24h_CTRL DOUBLE PRECISION ,
 SSc5P6_24h_LPA     DOUBLE PRECISION ,
 SSc6P6_24h_CTRL DOUBLE PRECISION ,
 SSc6P6_24h_LPA     DOUBLE PRECISION ,
 SSc8P5_24h_CTRL DOUBLE PRECISION ,
 SSc8P5_24h_LPA     DOUBLE PRECISION ,
 SSc9P6_24h_CTRL DOUBLE PRECISION ,
 SSc9P6_24h_LPA     DOUBLE PRECISION 
) PRIMARY INDEX (OBSID);")


head(sD)

